"""
train_rnn.py
============
RNN-Based Student Performance Evaluator
Tasks 1, 3, 4, 5, 6, 7, 8

Key difference from ANN
────────────────────────
  ANN  : processes all 5 features at once (no memory)
  RNN  : processes features ONE BY ONE as a sequence,
         maintaining a hidden state h(t) that "remembers"
         previous features when evaluating the next one.

  We treat the 5 features as time steps:
    t=0 → attendance
    t=1 → assignment
    t=2 → quiz
    t=3 → mid
    t=4 → study_hours
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score, confusion_matrix,
    classification_report, ConfusionMatrixDisplay,
)
from rnn_model import SimpleRNN

# ─────────────────────────────────────────────
# TASK 1 – Dataset Overview
# ─────────────────────────────────────────────
print("=" * 60)
print("TASK 1 – DATASET OVERVIEW")
print("=" * 60)

df = pd.read_excel("dataset.xlsx")
print("\n📌 First 5 rows:")
print(df.head())
print(f"\n📌 Shape : {df.shape}")
print(f"📌 Columns : {df.columns.tolist()}")
print(f"\n📌 Target distribution:\n{df['result'].value_counts()}")

print("""
📖 Why RNN for this data?
────────────────────────────────────────────────────────
  An RNN processes the student's features one at a time,
  treating them as a sequence:
    attendance → assignment → quiz → mid → study_hours

  At each step, the hidden state h(t) accumulates context
  from all previously seen features.  When the RNN reads
  'study_hours', it already "knows" the student's attendance,
  quiz and mid scores — enabling richer, context-aware
  predictions compared to a plain ANN.

  Problem type: CLASSIFICATION (Pass=1 / Fail=0)
""")

# ─────────────────────────────────────────────
# TASK 3 – Preprocessing
# ─────────────────────────────────────────────
print("=" * 60)
print("TASK 3 – PREPROCESSING")
print("=" * 60)

FEATURE_COLS = ["attendance", "assignment", "quiz", "mid", "study_hours"]
X = df[FEATURE_COLS].values.astype(float)
y = df["result"].values.astype(float)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s  = scaler.transform(X_test)

print(f"✅ Train : {X_train_s.shape}  |  Test : {X_test_s.shape}")

print("""
📖 How features become sequences for RNN
────────────────────────────────────────────────────────
  Each student row  [att, asgn, quiz, mid, hrs]
  becomes a sequence of 5 time steps, each of shape (1,):

    x(0) = [att]   x(1) = [asgn]   x(2) = [quiz]
    x(3) = [mid]   x(4) = [hrs]

  The RNN reads left → right, building up hidden state.
""")

def to_sequences(X_scaled):
    """Convert (N, 5) matrix → list of (5, 1) sequences."""
    return [X_scaled[i].reshape(5, 1) for i in range(len(X_scaled))]

train_seqs = to_sequences(X_train_s)
test_seqs  = to_sequences(X_test_s)

# ─────────────────────────────────────────────
# TASK 4 – Build RNN
# ─────────────────────────────────────────────
print("=" * 60)
print("TASK 4 – RNN ARCHITECTURE")
print("=" * 60)

print("""
📖 RNN Architecture
────────────────────────────────────────────────────────
  input_size  = 1   (one feature per time step)
  hidden_size = 32  (recurrent neurons — the "memory")
  output_size = 1   (Pass / Fail probability)
  time_steps  = 5   (one per feature)

  Equations:
    h(t) = tanh( Wxh·x(t) + Whh·h(t-1) + bh )
    y    = sigmoid( Why·h(T) + by )

  Total trainable parameters:
    Wxh  : 32×1  =   32
    Whh  : 32×32 = 1024
    Why  :  1×32 =   32
    bh   : 32×1  =   32
    by   :  1×1  =    1
    ─────────────────────
    Total          1121
""")

rnn = SimpleRNN(input_size=1, hidden_size=32, output_size=1, seed=42)

# ─────────────────────────────────────────────
# TASK 5 – Train
# ─────────────────────────────────────────────
print("=" * 60)
print("TASK 5 – TRAINING")
print("=" * 60)

EPOCHS   = 80
LR       = 0.005
MOMENTUM = 0.9

train_losses = []
train_accs   = []

print(f"⏳ Training RNN for {EPOCHS} epochs …\n")

for epoch in range(EPOCHS):
    epoch_loss = 0.0
    correct    = 0

    # Shuffle training data each epoch
    indices = np.random.permutation(len(train_seqs))

    for i in indices:
        x_seq  = train_seqs[i]
        y_true = y_train[i]

        # Forward
        y_pred, cache = rnn.forward(x_seq)

        # Binary cross-entropy loss
        eps  = 1e-9
        loss = -(y_true * np.log(y_pred + eps) +
                 (1 - y_true) * np.log(1 - y_pred + eps))
        epoch_loss += loss

        # Backward + update
        grads = rnn.backward(cache, y_true)
        rnn.update(grads, lr=LR, momentum=MOMENTUM)

        if (y_pred >= 0.5) == (y_true == 1):
            correct += 1

    avg_loss = epoch_loss / len(train_seqs)
    acc      = correct / len(train_seqs)
    train_losses.append(avg_loss)
    train_accs.append(acc)

    if (epoch + 1) % 10 == 0:
        print(f"  Epoch {epoch+1:3d}/{EPOCHS}  |  "
              f"Loss: {avg_loss:.4f}  |  Train Acc: {acc:.2%}")

print(f"\n✅ Training complete!")

# ─────────────────────────────────────────────
# TASK 6 – Evaluate
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("TASK 6 – EVALUATION ON TEST SET")
print("=" * 60)

y_pred_list = [rnn.predict(seq) for seq in test_seqs]
y_prob_list = [rnn.predict_proba(seq) for seq in test_seqs]

acc = accuracy_score(y_test, y_pred_list)
print(f"\n✅ Test Accuracy : {acc * 100:.2f}%")

print("\n📊 Classification Report:")
print(classification_report(y_test, y_pred_list,
                             target_names=["Fail (0)", "Pass (1)"]))

cm = confusion_matrix(y_test, y_pred_list)
print(f"📊 Confusion Matrix:\n{cm}")
print(f"   TN={cm[0,0]}  FP={cm[0,1]}")
print(f"   FN={cm[1,0]}  TP={cm[1,1]}")

# ── Plots ──────────────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(15, 4))

# Loss curve
axes[0].plot(train_losses, color="#2563eb", linewidth=2)
axes[0].set_title("Training Loss (Cross-Entropy)")
axes[0].set_xlabel("Epoch"); axes[0].set_ylabel("Loss")
axes[0].grid(alpha=0.3)

# Accuracy curve
axes[1].plot(train_accs, color="#16a34a", linewidth=2)
axes[1].set_title("Training Accuracy")
axes[1].set_xlabel("Epoch"); axes[1].set_ylabel("Accuracy")
axes[1].set_ylim(0, 1); axes[1].grid(alpha=0.3)

# Confusion matrix heatmap
disp = ConfusionMatrixDisplay(cm, display_labels=["Fail", "Pass"])
disp.plot(ax=axes[2], cmap="Blues", colorbar=False)
axes[2].set_title("Confusion Matrix")

plt.suptitle("RNN Student Performance Evaluator", fontsize=13, fontweight="bold")
plt.tight_layout()
plt.savefig("rnn_training_plots.png", dpi=150)
print("\n✅ Training plots saved → rnn_training_plots.png")

# ─────────────────────────────────────────────
# TASK 7 – evaluate_student function
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("TASK 7 – EVALUATE_STUDENT FUNCTION")
print("=" * 60)

def evaluate_student(attendance, assignment, quiz, mid, study_hours):
    """
    RNN-based student performance predictor.

    Processes features as a 5-step sequence:
      t=0: attendance  →  t=1: assignment  →  t=2: quiz
      t=3: mid         →  t=4: study_hours

    Parameters
    ----------
    attendance  : float (0-100)
    assignment  : float (0-100)
    quiz        : float (0-100)
    mid         : float (0-100)
    study_hours : float (hours/week)

    Returns
    -------
    dict: prediction, label, probability, performance
    """
    raw = np.array([[attendance, assignment, quiz, mid, study_hours]])
    scaled = scaler.transform(raw)
    x_seq  = scaled.reshape(5, 1)

    probability = rnn.predict_proba(x_seq)
    prediction  = 1 if probability >= 0.5 else 0
    label       = "Pass ✅" if prediction == 1 else "Fail ❌"
    performance = ("High 🌟" if probability >= 0.75 else
                   "Medium 📈" if probability >= 0.50 else
                   "Low 📉")

    return {
        "prediction":  prediction,
        "label":       label,
        "probability": float(probability),
        "performance": performance,
    }

# Demo
demo = evaluate_student(85, 78, 72, 65, 8)
print(f"\n🧪 Demo → evaluate_student(85, 78, 72, 65, 8)")
print(f"   Result      : {demo['label']}")
print(f"   Pass Prob   : {demo['probability']:.2%}")
print(f"   Performance : {demo['performance']}")

# ─────────────────────────────────────────────
# TASK 8 – Save
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("TASK 8 – SAVING MODEL & SCALER")
print("=" * 60)

joblib.dump(rnn,    "rnn_model.joblib")
joblib.dump(scaler, "rnn_scaler.joblib")
print("✅ rnn_model.joblib  saved")
print("✅ rnn_scaler.joblib saved")

print("""
📖 Why save both?
─────────────────
  rnn_model.joblib  — contains all learned weights:
                      Wxh, Whh, Why, bh, by
  rnn_scaler.joblib — contains the mean & std learned
                      from training data.  New inputs MUST
                      be scaled with the SAME scaler or the
                      weight values will be meaningless.
""")

print("🎉 Done!  Run  streamlit run rnn_app.py  to launch the UI.")
