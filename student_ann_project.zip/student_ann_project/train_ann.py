"""
train_ann.py
============
ANN-Based Student Performance Evaluator
Covers Tasks 1, 3, 4, 5, 6, 7, 8
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")          # non-interactive backend (no display needed)
import matplotlib.pyplot as plt
import joblib
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    ConfusionMatrixDisplay,
)

# ─────────────────────────────────────────────
# TASK 1 – Understand the Dataset
# ─────────────────────────────────────────────
print("=" * 60)
print("TASK 1 – DATASET OVERVIEW")
print("=" * 60)

df = pd.read_excel("dataset.xlsx")

print("\n📌 First 5 rows:")
print(df.head())

print("\n📌 Column names:", df.columns.tolist())
print("📌 Shape (rows × cols):", df.shape)

print("\n📌 Data types & null counts:")
print(df.info())

print("\n📌 Basic statistics:")
print(df.describe())

print("\n📌 Target variable distribution:")
print(df["result"].value_counts())
print(f"   0 = Fail  |  1 = Pass")

print("""
📖 Column Explanations
─────────────────────────────────────────────
  attendance  – % of classes attended (0-100)
  assignment  – marks scored in assignments (0-100)
  quiz        – marks scored in quizzes (0-100)
  mid         – mid-term exam marks (0-100)
  study_hours – self-reported weekly study hours
  result      – binary target: 0 = Fail, 1 = Pass

🧠 Problem Type: CLASSIFICATION
   The target 'result' is a discrete binary label (0 or 1),
   not a continuous value.  We predict which class a student
   belongs to, so this is a classification problem.
""")

# ─────────────────────────────────────────────
# TASK 3 – Data Preprocessing
# ─────────────────────────────────────────────
print("=" * 60)
print("TASK 3 – DATA PREPROCESSING")
print("=" * 60)

# Separate features and target
X = df[["attendance", "assignment", "quiz", "mid", "study_hours"]]
y = df["result"]

print(f"\n✅ Feature matrix X shape : {X.shape}")
print(f"✅ Target vector  y shape : {y.shape}")

# Train / test split (80 / 20)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)
print(f"\n✅ Training samples : {len(X_train)}")
print(f"✅ Testing  samples : {len(X_test)}")

# Feature scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled  = scaler.transform(X_test)

print("""
📖 Why Scaling is Required in ANN
────────────────────────────────────────────────────────
  ANNs use gradient descent to update weights. If features
  are on different scales (e.g., attendance 0-100 vs
  study_hours 0-20), larger-magnitude features dominate
  the gradient updates, making training slow or unstable.

  StandardScaler transforms each feature so that:
      mean = 0,  standard deviation = 1

  This puts all features on the same footing, letting the
  network learn each feature's importance fairly.
""")

# ─────────────────────────────────────────────
# TASK 4 – Build ANN Model
# ─────────────────────────────────────────────
print("=" * 60)
print("TASK 4 – ANN ARCHITECTURE")
print("=" * 60)

print("""
📖 ANN Concepts
────────────────────────────────────────────────────────
  Neurons        – basic units that receive inputs, apply
                   a weighted sum, add bias, then pass the
                   result through an activation function.

  Activation     – introduces non-linearity so the network
  Functions        can learn complex patterns.
                   • ReLU  : max(0, x)  – used in hidden layers
                   • Logistic / Sigmoid – used in output for
                     binary classification (outputs probability)

  Hidden Layers  – layers between input and output that let
                   the ANN learn intermediate representations
                   of the data.  More layers / neurons = more
                   expressive power (but risk of overfitting).

  Our architecture
  ─────────────────
   Input Layer  : 5 neurons  (one per feature)
   Hidden Layer 1 : 64 neurons, ReLU
   Hidden Layer 2 : 32 neurons, ReLU
   Output Layer : 1 neuron (2-class softmax internally)
""")

# Build the model
model = MLPClassifier(
    hidden_layer_sizes=(64, 32),   # 2 hidden layers
    activation="relu",
    solver="adam",
    max_iter=500,
    random_state=42,
    verbose=False,
    early_stopping=True,
    validation_fraction=0.1,
    n_iter_no_change=20,
)

# ─────────────────────────────────────────────
# TASK 5 – Train the Model
# ─────────────────────────────────────────────
print("=" * 60)
print("TASK 5 – TRAINING")
print("=" * 60)

print("⏳  Training ANN …")
model.fit(X_train_scaled, y_train)

print(f"✅  Training complete!")
print(f"    Iterations run    : {model.n_iter_}")
print(f"    Final train loss  : {model.loss_:.6f}")

# ─────────────────────────────────────────────
# TASK 6 – Evaluate the Model
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("TASK 6 – MODEL EVALUATION")
print("=" * 60)

y_pred = model.predict(X_test_scaled)

acc = accuracy_score(y_test, y_pred)
print(f"\n✅  Test Accuracy : {acc * 100:.2f}%")

print("\n📊  Classification Report:")
print(classification_report(y_test, y_pred, target_names=["Fail (0)", "Pass (1)"]))

cm = confusion_matrix(y_test, y_pred)
print("📊  Confusion Matrix:")
print(cm)
print(f"    TN={cm[0,0]}  FP={cm[0,1]}")
print(f"    FN={cm[1,0]}  TP={cm[1,1]}")

print("""
📖 Interpretation
─────────────────
  Accuracy   – % of students correctly classified overall.
  Precision  – of those predicted Pass, how many truly Pass?
  Recall     – of all actual Pass students, how many did we catch?
  F1-Score   – harmonic mean of precision & recall.

  Mistakes the model might make
  • False Positive (FP): predicted Pass but student actually Fails
  • False Negative (FN): predicted Fail but student actually Passes
""")

# ── Confusion matrix heatmap (bonus) ──────────────────────
disp = ConfusionMatrixDisplay(confusion_matrix=cm,
                               display_labels=["Fail", "Pass"])
fig, ax = plt.subplots(figsize=(5, 4))
disp.plot(ax=ax, cmap="Blues", colorbar=False)
ax.set_title("Confusion Matrix – ANN Student Evaluator", fontsize=12)
plt.tight_layout()
plt.savefig("confusion_matrix.png", dpi=150)
print("✅  Confusion matrix saved → confusion_matrix.png")

# ── Loss curve ────────────────────────────────────────────
fig2, ax2 = plt.subplots(figsize=(6, 4))
ax2.plot(model.loss_curve_, label="Training Loss", color="#2563eb")
if hasattr(model, "validation_scores_") and model.validation_scores_:
    ax2.plot(
        [1 - v for v in model.validation_scores_],
        label="Validation Loss (1-acc)",
        color="#f59e0b",
        linestyle="--",
    )
ax2.set_xlabel("Epoch")
ax2.set_ylabel("Loss")
ax2.set_title("ANN Training Loss Curve")
ax2.legend()
plt.tight_layout()
plt.savefig("loss_curve.png", dpi=150)
print("✅  Loss curve saved → loss_curve.png")

# ─────────────────────────────────────────────
# TASK 7 – Evaluation Function
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("TASK 7 – EVALUATE_STUDENT FUNCTION")
print("=" * 60)

def evaluate_student(attendance, assignment, quiz, mid, study_hours):
    """
    Predicts whether a new student will Pass or Fail.

    Parameters
    ----------
    attendance  : float  (0-100)
    assignment  : float  (0-100)
    quiz        : float  (0-100)
    mid         : float  (0-100)
    study_hours : float  (hours per week)

    Returns
    -------
    dict with keys: prediction (int), label (str), probability (float)
    """
    features = np.array([[attendance, assignment, quiz, mid, study_hours]])
    features_scaled = scaler.transform(features)
    prediction = model.predict(features_scaled)[0]
    probability = model.predict_proba(features_scaled)[0][1]   # P(Pass)
    label = "Pass ✅" if prediction == 1 else "Fail ❌"
    return {"prediction": int(prediction), "label": label, "probability": float(probability)}


# Quick demo
sample = evaluate_student(85, 78, 72, 65, 8)
print(f"\n🧪 Demo – evaluate_student(85, 78, 72, 65, 8)")
print(f"   Result      : {sample['label']}")
print(f"   Pass Prob   : {sample['probability']:.2%}")

# ─────────────────────────────────────────────
# TASK 8 – Save Model & Scaler
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("TASK 8 – SAVING MODEL & SCALER")
print("=" * 60)

joblib.dump(model,  "model.joblib")
joblib.dump(scaler, "scaler.joblib")

print("✅  model.joblib  saved")
print("✅  scaler.joblib saved")
print("""
📖 Why save BOTH?
─────────────────
  The scaler learned the mean and std from training data.
  Any new student's features MUST be transformed with the
  SAME scaler before passing to the model.  If we only save
  the model and re-fit a new scaler on new data, the feature
  values would be on a different scale → wrong predictions.
""")

print("\n🎉  All tasks complete!  Run  streamlit run app.py  for the UI.")
