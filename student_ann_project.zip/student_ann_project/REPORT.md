# 🎓 ANN Student Performance Evaluator — Final Explanation Report

---

## 1. What is ANN in Your Own Words?

An **Artificial Neural Network (ANN)** is a computer program inspired by the human brain. Just like our brain has billions of neurons connected to each other, an ANN has artificial "neurons" (called nodes or units) arranged in layers.

Each neuron:
1. Receives some numbers as input
2. Multiplies them by **weights** (importance values it has learned)
3. Adds them up and passes the result through an **activation function**
4. Sends the output to the next layer

Through **training**, the ANN automatically adjusts its weights by seeing thousands of examples, so it gradually gets better at predicting the right answer. Once trained, it has effectively "memorized" a pattern — the function `f(x) → y`.

---

## 2. What Function Did Your Model Learn?

Our model learned the function:

```
f(attendance, assignment, quiz, mid, study_hours) → Pass or Fail
```

More precisely, it learned to output the **probability that a student will pass** given those five inputs. Internally, the ANN created a complex, non-linear decision boundary in a 5-dimensional feature space that separates passing students from failing ones.

The function is not a simple formula — it is encoded in ~7,000 weight values spread across two hidden layers.

---

## 3. How Does Your System Evaluate a New Student?

When a new student's data is entered:

1. **Input** → collect `(attendance, assignment, quiz, mid, study_hours)`
2. **Scale** → apply the saved `StandardScaler` to transform values to zero-mean, unit-variance
3. **Forward Pass** → pass scaled values through the trained ANN layers
4. **Output** → the network outputs `P(Pass)` — a probability between 0 and 1
5. **Decision** → if `P(Pass) ≥ 0.5` → **Pass**, else → **Fail**
6. **Band** → classify as Low / Medium / High based on probability

The key point: steps 2-5 happen in milliseconds, and the student does **not** need to be in the training dataset.

---

## 4. Why Is Scaling Important?

Consider the raw features:
| Feature       | Typical Range |
|---------------|--------------|
| attendance    | 0 – 100 |
| assignment    | 0 – 100 |
| quiz          | 0 – 100 |
| mid           | 0 – 100 |
| study_hours   | 0 – 20  |

Without scaling, the gradient updates during training are dominated by features with larger magnitudes. The network would effectively treat `study_hours = 10` as trivial compared to `attendance = 75`, even though study hours may be a very important predictor.

`StandardScaler` converts each feature to: `z = (x − mean) / std`

This ensures all features start on an equal footing and the optimizer (Adam) converges faster and more reliably.

---

## 5. Limitations of the Model

| Limitation | Explanation |
|------------|-------------|
| **Synthetic data** | The dataset was synthetically generated, so the model may not perfectly represent real student behaviour |
| **Black box** | ANN weights are not human-interpretable — we cannot easily explain *why* a student is predicted to fail |
| **Binary output** | Result is only Pass / Fail; no nuance like "borderline" or grade predictions |
| **No temporal data** | The model sees a snapshot; it ignores improvement trends over time |
| **Feature scope** | Important factors like socioeconomic background, health, or learning disabilities are not captured |
| **Overfitting risk** | With small datasets, the model may memorise training data and generalise poorly |
| **Static thresholds** | The 0.5 decision threshold is not tuned — adjusting it could improve recall for at-risk students |

---

## Project Structure

```
student_ann_project/
│
├── dataset.xlsx        ← original student data
├── train_ann.py        ← Tasks 1, 3–8: training pipeline
├── predict.py          ← Task 7 + CLI interface (Option A)
├── app.py              ← Streamlit UI (Option B)
├── model.joblib        ← trained ANN weights
├── scaler.joblib       ← fitted StandardScaler
├── confusion_matrix.png
├── loss_curve.png
└── requirements.txt
```

---

## How to Run

```bash
# Step 1: Install dependencies
pip install -r requirements.txt

# Step 2: Train the model (generates model.joblib & scaler.joblib)
python train_ann.py

# Step 3a: CLI prediction
python predict.py 85 78 72 65 8
# or interactive:
python predict.py

# Step 3b: Streamlit UI
streamlit run app.py
```

---

*Report prepared as part of the ANN-Based Student Performance Evaluator assignment.*
